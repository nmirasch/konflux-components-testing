# argocd-rbac-cm.yaml example

An example of an argocd-rbac-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-rbac-cm.yaml!}
```
