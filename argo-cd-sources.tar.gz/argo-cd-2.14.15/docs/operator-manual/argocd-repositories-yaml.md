# argocd-repositories.yaml example

An example of an argocd-repositories.yaml file:

```yaml
{!docs/operator-manual/argocd-repositories.yaml!}
```
