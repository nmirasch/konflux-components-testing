# argocd-rbac-cm.yaml example

**Note**: While policy files are CSV files, ArgoCD ignores lines starting with `#` when parsing the file, allowing for line comments starting with #.

An example of an argocd-rbac-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-rbac-cm.yaml!}
```
