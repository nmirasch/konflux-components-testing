# argocd-cmd-params-cm.yaml example

An example of an argocd-cmd-params-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-cmd-params-cm.yaml!}
```
